INSTALLATION DE L'APPLICATION MEDIATEK86
****************************************

- Le fichier 'Mediatek86 Installer.msi' installe l'application
- Le dossier 'MediatekImages' doit être placé en racine de c: (c:\MediatekImages)


COMPTES UTILISATEURS
********************

Compte administrateur : tous les droits
- Nom d'utilisateur : admin 
- Mot de passe : admin
Compte Services Administratifs : tous les droits
- Nom d'utilisateur: serviceadmin
- Mot de passe: serviceadmin
Compte Service Prêts : droit de consultation des catalogues livres, DVD, revues et exemplaires revues
- Utilisateur : pret
- Mot de passe : pret
Compte Service Culture : aucun droit, pas d'accès à l'application
- Utilisateur : culture
- Mot de passe : culture